﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();                                       // Initialize 
            
        }

        private void button1_Click(object sender, EventArgs e)           // When Button Clicked
        {
            Thread.Sleep(3000);                                          // Temperary for Debug
            string location = @"C:\Users\Public\Documents\rice and bean\rice";
            int loop = Convert.ToInt32(textBox2.Text);               // Amount of times
            while(loop < 101)
            {
                location = @"C:\Users\Public\Documents\rice and bean\rice";
                location = location + Convert.ToString(loop) + ".txt";
                typeString(System.IO.File.ReadAllText(location));        // Run function to type contents
                SendKeys.Send("{ENTER}");                                // Enter lmao 
                loop = loop + 1;                                         // Lessen Loop
                Thread.Sleep(Convert.ToInt32(textBox1.Text));
            }
            
        }

        public string typeString(string letters)                         // Type the inputed string
        {
            // Variables for this function

            string text = letters;                                       // String to be typed
            int length = text.Length;                                    // Length of string
            int firstDigit = 0;                                          // Charnumber for substring                          

            while (length > 0)                                           // Loops until all chars printed
            {
                string character = text.Substring(firstDigit, 1);        // Graps current substring char

                string outp = "{" + character + "}";                     // Add brackets to individual char

                if(character == " ")
                {
                    outp = " ";
                }


                firstDigit = firstDigit + 1;                             // Go to next char in string
                length = length - 1;                                     // Loop
                try
                {
                    SendKeys.Send(outp);                                     // Type char
                }
                catch
                {
                }
            }
            return " ";                                                  // Return to complete function
        }

        //Reference Text Box
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
